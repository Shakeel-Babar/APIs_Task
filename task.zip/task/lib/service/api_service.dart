import 'dart:convert';
import 'package:http/http.dart' as http;
import '../model/object_model.dart';


class ApiService {
  static const String apiUrl = 'https://api.restful-api.dev/objects';

  Future<List<ObjectModel>> fetchObjects() async {
    final response = await http.get(Uri.parse(apiUrl));

    if (response.statusCode == 200) {
      List<dynamic> body = jsonDecode(response.body);
      List<ObjectModel> objects = body.map((dynamic item) => ObjectModel.fromJson(item)).toList();
      return objects;
    } else {
      throw Exception('Failed to load objects');
    }
  }
}
