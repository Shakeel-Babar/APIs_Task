import 'package:flutter/material.dart';
import 'package:task/service/api_service.dart';

import 'model/object_model.dart';

class MyHomePage extends StatefulWidget {
  const MyHomePage({super.key});

  @override
  State<MyHomePage> createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  late Future<List<ObjectModel>> futureObjects;

  @override
  void initState() {
    super.initState();
    futureObjects = ApiService().fetchObjects();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('API Data'),
      ),
      body: FutureBuilder<List<ObjectModel>>(
        future: futureObjects,
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return Center(child: CircularProgressIndicator());
          } else if (snapshot.hasError) {
            return Center(child: Text('Error: ${snapshot.error}'));
          } else if (!snapshot.hasData || snapshot.data!.isEmpty) {
            return Center(child: Text('No data found'));
          } else {
            return ListView.builder(
              itemCount: snapshot.data!.length,
              itemBuilder: (context, index) {
                ObjectModel object = snapshot.data![index];
                return ListTile(
                  title: Text(object.name),
                  subtitle: Text(object.data != null ? object.data.toString() : 'No additional data'),
                );
              },
            );
          }
        },
      ),
    );
  }
}
